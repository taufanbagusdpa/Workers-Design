@extends('layouts.default')
@section('content')
  <div class="logo">Workers</br>Design</div>
  <canvas id="canvas" class="Fibrous"></canvas>
@endsection
