<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detail_Post extends Model
{
  protected $table = 'detail_post';
  public $timestamps = true;
}
